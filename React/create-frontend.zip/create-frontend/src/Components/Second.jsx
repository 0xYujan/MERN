export const Second1 = () =>{
    return (
        <>
            <h2 style={{color:"purple"}}>I am the first name export from Second.jsx file</h2>
        </>
    )
}

export const Second2 = () =>{
    return (
        <>
          <h2 style={{color:"lightblue"}}>I am the second name export from Second.jsx file</h2>
        </>
    )
}