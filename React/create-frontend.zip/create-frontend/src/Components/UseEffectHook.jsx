//Syntax:
/*useEffect(() =>{
    return cleanup function
    }, [dependencies array])
*/

const UseEffectHook = ()=>{
    return (
        <>
        </>
    )
}

export default UseEffectHook