import React from "react";
import Navbar from "../Components/Navbar";
import HeroSection from "../Components/HeroSection";
import Footer from "../Components/Footer";
import DisplayProduct from "../Components/Product/DisplayProducts";
import DisplayIdCard from "../Components/idCard/DisplayIdCard";
import Counter from "../Components/Counter";
import Drawer from "../Components/Drawer";

const HomePage = () =>{
    return(

        <div className="">
      
        {/* <HeroSection /> */}
        <DisplayProduct />
        {/* <DisplayIdCard /> */}
        {/* <Counter /> */}
        {/* <Drawer /> */}

    </div>
    )
}

export default HomePage