import Navbar from "../Components/Navbar"

const Contact = () =>{
    return (
        <>
     
            <h1>Test Contact US</h1>

        </>
    )
}

export default Contact