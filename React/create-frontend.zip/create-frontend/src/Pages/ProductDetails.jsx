import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import SingleProduct from "../UI Components/SingleProduct";

const ProductDetails = () => {
  const { productId } = useParams();
  const [product, setProduct] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDetails = async () => {
      try {
        const { data } = await axios.get(`https://dummyjson.com/products/${productId}`);
        setProduct(data);
        setIsLoading(false);
      } catch (err) {
        setError(err.message);
        setIsLoading(false);
      }
    };
    fetchDetails();
  }, [productId]);

  if (isLoading) {
    return <h2>Loading......</h2>;
  }

  if (error) {
    return <h1>{error}</h1>;
  }

  return (
    <div className="container-fluid">
      <div className="row row-cols-1 row-cols-md-4 g-4">
        {product && (
          <SingleProduct
            id={product.id}
            image={product.images}
            price={product.price}
            title={product.title}
            description={product.description}
            rating={product.rating}
            warranty = {product.warrantyInformation}
            category = {product.category}
            brand = {product.brand}
            stock = {product.stock}
            availability = {product.availabilityStatus}
            returnPolicy = {product.returnPolicy}
            qrCode = {product.meta.qrCode}
            discount = {product.discountPercentage}

          />
        )}
      </div>
    </div>
  );
};

export default ProductDetails;
