import Navbar from "../Components/Navbar"

const About = () =>{
    return (
        <>
        
        <h1>Test About US</h1>
        </>
    )
}

export default About