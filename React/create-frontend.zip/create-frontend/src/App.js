// import "./App.css";
// import First from "./Components/first";
// import { Second1, Second2 } from "./Components/Second";
import MyRoutes from "./MyRoutes";
// import HomePage from "./Pages/HomePage";
// import { Second1 } from "./components/second";

function App() {
  return (
    <div className="App">
     <MyRoutes />
    </div>
  );
}

export default App;
