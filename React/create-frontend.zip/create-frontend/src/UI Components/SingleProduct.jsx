import { Link } from "react-router-dom";

const SingleProduct = ({ title, image,qrCode, discount, description, warranty, price, rating, category, brand, stock, availability, returnPolicy  }) => {
  return (

    <div class="container">
        <br />
  <div class="row">
  <div class="col-1">
    </div>
    <div class="col">
          <img src={image} style={{height:"300px"}} alt={title} />
    </div>
    <div class="col-6">
      <h1>{title}</h1>
      <br />
    <p>{rating} Rating</p>
  
    <p>Brand: {brand}</p>
    <br /><br />
    <hr />
    <br />
    <h1>Rs. {price * 134}</h1>
    <h3>{discount}%</h3>
    <br /><br/>
    <p>Stock: {stock}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   Warranty:  {warranty}</p>
      <p> </p><br />
      
<button type="button" class="btn btn-warning">Buy Now</button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button type="button" class="btn btn-info">Add To Cart</button>

    </div><br />
    <hr />
    
    <div class="col-6">

    </div>
   
  </div><br /><br />
  <div class="row">
    <div class="col-2">
    
    </div>
    <div class="col-5">
     
      <p>{description}</p>
      <br/>
      <p>category: {category}</p>
      <p>availability: {availability}</p>
      <p>returnPolicy: {returnPolicy}</p>
      <br/>

    </div>
    <div class="col">
              <img src={qrCode} style={{height:"200px"}} alt={title} />

    </div>
  </div>
</div>
  );
};

export default SingleProduct;
